Thư mục Plus:
- Chứa những chương trình do các bạn viết để xử lý, cải tiến, tiền xử lý/hậu xử lý,  khi xây dựng ngữ liệu song song này.
- Không nộp những công cụ có sẵn ở bên ngoài.
